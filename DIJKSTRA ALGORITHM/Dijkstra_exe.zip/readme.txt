Put all in a directory and run run.bat. Then use the Algorithms.exe

